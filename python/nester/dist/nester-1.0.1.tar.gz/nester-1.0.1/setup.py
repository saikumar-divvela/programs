from distutils.core import setup
#   python  setup.py sdist
#   sudo python setup.py install

setup (
    name="nester",
    version="1.0.1",
    py_modules = ["nester"],
    author="saikumar",
    author_email="sai.divvela@xyz.com",
    url="http://google.com",
    description="A simple printer of nested lists"
    )
    
