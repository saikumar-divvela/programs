from distutils.core import setup

setup (
    name="nester",
    version="1.0.0",
    py_modules = ["nester"],
    author="saikumar",
    author_email="sai.divvela@xyz.com",
    url="http://google.com",
    description="A simple printer of nested lists"
    )
    
